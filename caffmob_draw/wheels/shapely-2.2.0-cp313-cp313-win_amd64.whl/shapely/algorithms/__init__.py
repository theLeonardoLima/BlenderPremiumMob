"""Algorithms implemented in Shapely."""
